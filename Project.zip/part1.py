import json
import pickle as pkl
import re

def main():
    return
    # -----
    # 1. Load corpus data using your load_corpus_data function.
    # 2. Use the save_pkl utility function to save this data to a file named
    #    data.pkl
    # 3. Obtain the word frequency dictionary using your get_word_freq function.
    # 4. Use the save_json utility function to save the word frequency
    #    dictionary to a file named wfd.json
    # 5. Obtain two lists of words: top 100 and top 5000.
    # 6. Save the two lists in two files named top_100_list.txt and
    #    top_5000_list.txt respectively. Write plain text words, one word per
    #    line. You will need to write your own code for that (instead of using a
    #    function). Refer to your lecture notes or Python documentation for
    #    how to do that. The words should be ordered by decreasing frequency.
    # 7. Generate a frequency graph for the top 100 words, and use the
    #    graph_top_k function to save it to a file named top_100_fig.png
    # 8. Answer the question: What type of behavior do English words exhibit?
    #    What is the class of functions that describe such behavior? What is the
    #    name of this law in linguistics? Answers should be inside comments.
    #


def load_pkl(file_name):
    with open(file_name, 'rb') as f:
        data = pkl.load(f)
    return data


def save_pkl(file_name, data):
    with open(file_name, 'wb') as f:
        pkl.dump(data, f)


def load_json(file_name):
    with open(file_name) as f:
        data = json.load(f)
    return data


def save_json(file_name, data):
    with open(file_name, 'w') as f:
        json.dump(data, f)


def load_corpus_data(file_name):
    f = open(file_name, "r")
    words = extract_words(f.read())
    print(words)
    return words


def get_word_freq(data):
    wfd = dict()
    for word in data:
        if wfd.get(word) is None:
            wfd[word] = 1
        else:
            wfd[word] = wfd[word] + 1
    print(wfd)
    return wfd


def extract_words(sentence):
    sentence = sentence.lower()
    pattern = re.compile("[A-Za-z]+")
    words = pattern.findall(sentence)
    words = [w for w in words if len(w) > 1]
    print(words)
    return words


def top_k_words(wfd, k):
    top_k = []
    entry = wfd.keys()
    sortedlist = sorted(entry, key=wfd.__getitem__, reverse=True)
    for i in range(0, k - 1):
        top_k.append(sortedlist.__getitem__(i))
    print(top_k)
    return top_k


def graph_top_k(wfd, top_k, file_name):
    fs = []

    fig = plt.figure(figsize=(800 / 192, 800 / 192), dpi=192)
    plt.bar(range(1, len(fs) + 1), fs, figure=fig)
    plt.ylabel("frequency")
    plt.xlabel("rank")
    plt.title('Brown corpus word frequency')
    plt.tight_layout()
    plt.savefig(figure=fig, fname=file_name, pad_inches=0.5)


if __name__ == "__main__":
    main()

data = load_corpus_data("english-brown.txt")

save_pkl("data.pkl", data)

freq = get_word_freq(data)

save_json("wfd.json", freq)

top100 = top_k_words(freq, 100)

lines = top100
with open("Top_100.txt", "w") as f:
    for line in lines:
        f.write(line)
        f.write('\n')

top5000 = top_k_words(freq, 5000)

lines = top5000
with open("Top_5000.txt", "w") as f:
    for line in lines:
        f.write(line)
        f.write('\n')
