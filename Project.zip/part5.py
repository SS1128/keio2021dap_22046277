from assignment import *

def main():
    # -----
    # 1. Load the list of 100 most frequent words from Part I.
    # 2. Load the context dictionary using the load_pkl function.
    # 3. Compute the spectral word embeddings for the top 100 words.
    # 3. Create a text file called top_100_cos.txt, with 100 lines, each line
    #    corresponding to a word on the same line in the top_100_list.txt file.
    #    The top_100_cos.txt file should contain a series of 100 floating point
    #    numbers in each line (10000 numbers total). The numbers should be your
    #    computed spectral cosine angles corresponding to the words within the
    #    top_100_list.txt. This means the diagonal numbers should all be 1.0,
    #    and a number in row i, column j should represent the cosine between the
    #    ith and the jth words in the top_100_list.txt from step 1. Use your
    #    Use your implementation of the word_cosine_similarity function.
    # 4. Answer the question: Which method of finding nearest neighbors do you
    #    suspect might be better in general (context similarity or spectral
    #    similarity)? Why? Why do you think the results in this particular
    #    exercise might favor the context similarity method (think data size used).
    #
    # YOUR CODE GOES HERE
    #
    # YOUR ANSWERS GO HERE
    # -----
    return

if __name__ == "__main__":
    main()
